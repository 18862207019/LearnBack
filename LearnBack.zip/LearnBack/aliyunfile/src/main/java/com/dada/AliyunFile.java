package com.dada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author hupd
 */
@SpringBootApplication
public class AliyunFile {
  public static void main(String[] args) {
    SpringApplication.run(AliyunFile.class);
  }
}

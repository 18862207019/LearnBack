/**
 * 版权所有(C)，上海勾芒信息科技，2017，所有权利保留。
 * 
 * 项目名：	wxmall
 * 文件名：	SysEventType.java
 * 模块说明：	
 * 修改历史：
 * 2017年9月12日 - Debenson - 创建。
 */
package com.dada.config.rocketmq.message;

/**
 * 系统消息类型
 * @author HUPD
 */
public enum SysEventType {
  /**测试*/
  OUTPUT,
}

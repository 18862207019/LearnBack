package com.dada.config.rocketmq.transactional.producer;

/**
 * 生产者类型
 * @author hupd
 */
public enum ProducerSenderEnum {
    OUTPUT,
}

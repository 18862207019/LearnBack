package com.dada.config.redis.param;

/** 注解于方法上 */
public @interface MethodParamLock {}

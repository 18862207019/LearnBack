package com.dada.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dada.entity.task.SysTask;

public interface SysTaskMapper extends BaseMapper<SysTask> {
}
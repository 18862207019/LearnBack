package com.dada.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dada.entity.sys.SysRolePermission;

public interface SysRolePermissionMapper extends BaseMapper<SysRolePermission> {
}
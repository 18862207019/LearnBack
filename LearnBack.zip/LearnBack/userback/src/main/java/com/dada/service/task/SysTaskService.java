package com.dada.service.task;

import com.dada.entity.task.SysTask;
import com.baomidou.mybatisplus.extension.service.IService;
public interface SysTaskService extends IService<SysTask>{


}

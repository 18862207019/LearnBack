package com.dada.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dada.entity.sys.SysUser;

public interface SysUserMapper extends BaseMapper<SysUser> {
}
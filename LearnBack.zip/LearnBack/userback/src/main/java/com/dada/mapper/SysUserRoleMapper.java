package com.dada.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dada.entity.sys.SysUserRole;

public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {
}
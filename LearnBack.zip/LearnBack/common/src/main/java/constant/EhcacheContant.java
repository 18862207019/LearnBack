package constant;

public class EhcacheContant {

    /*默认缓存名称   用户获取一级缓存数据*/
    public static final String DEFAULT_CACHE_NAME = "USER_BACK";
    /*一级缓存数据key*/
    public final static String  USER_KEY="USER_";

}

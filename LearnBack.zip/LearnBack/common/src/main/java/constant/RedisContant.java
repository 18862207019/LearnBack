package constant;

public class RedisContant {

    /*redis 分布式锁的value值*/
    public final  static String REDIS_LOCK="REDIS_LOCK";

    /*redis缓存当前用户信息 key USER_ID value 当前用户信息*/
    public final static String  USER_KEY="USER_";
}
